# Calculadora de Notas - ISIL

Grade calculator application for ISIL students with light/dark mode support.

## Quick Start

```bash
npm install
npm run dev
```

Visit `http://localhost:3000`

## Deploy

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)

See full documentation in [README.md](./README.md)
